// index.js
const app = getApp();
import config from '../../config.js'
Page({
  data: {
    numbers: 0,     // 次数
    isRunning: false,  // 运行
    userInfo: null,   // 用户
    isUpdating: false,   // 更新
    updateTimer: null,    // 定时器ID
    showLoginPopup: false // 弹窗状态
  },

  onLoad() {
    // 绑定全局登录状态监听
    const app = getApp()
    app.onLoginStatusChange((isLoggedIn) => {
      this.setData({ isLoggedIn });
      if (isLoggedIn) this.startMonitoring();
    });
  },

  // 切换状态
  toggleUpdate() {
    const app = getApp()
    const { isUpdating } = this.data;
    
    if (isUpdating) {
      this.stopMonitoring();
    } else {
      // 登录检查
      if (!app.checkLogin()) {
        this.setData({ showLoginPopup: true })
        return // 应当停止
      }
      this.startMonitoring();
    }
  },

  closeLoginPopup() {
    this.setData({ 
      showLoginPopup: false 
    })
  },

  handleLogin(e) {
    const app = getApp()
    if (e.detail.errMsg === 'getUserInfo:ok') {
      wx.login({
        success: (res) => {
          // 发送 code 换取 token
          wx.request({
            url: `${config.apiBaseUrl}/auth`,
            method: 'POST',
            data: {
              username: 'admin',
              password: 'password123'  //登录的部分
            },
            success: (res) => {
              const token = res.data.token;
              wx.setStorageSync('token', token);  // 存储 token
              this.startMonitoring();  // 开始监控
            }
          });  
        }
      })
    } else {
      wx.showToast({ title: '授权已取消', icon: 'none' })
      this.closeLoginPopup() // 关闭弹窗
    }
  },

  // 开始监控
  startMonitoring() {
    this.setData({ 
      lastTimestamp: 0,  // 时间戳
      isUpdating: true,
      lowHeadTime: 0,       // 数据归零
      lowHeadCount: 0,
      score: 0,
      totalConnectionTime: 0
    });
    
    // 获取数据
    this.fetchData();
    
    // 启动定时器
    this.setData({
      updateTimer: setInterval(() => {
        this.fetchData();
      }, 5000)
    });
  },

  // 停止监控
  stopMonitoring() {
    const { updateTimer } = this.data;
    clearInterval(updateTimer); // 清除定时器
    this.setData({ 
      isUpdating: false,
      updateTimer: null 
    });
  },

  // 拉取内容
  async fetchData() {
    if (this.data.isRefreshing) return; 
    this.setData({ isRefreshing: true });
    
    try {
      const data = await this.requestBackend('/data', 'GET');
      
      // 时间戳对比  
      console.log('接收到时间戳:', data.timestamp, '上次时间戳:', this.data.lastTimestamp);  
      if (data.timestamp > this.data.lastTimestamp) {  
        this.setData({
          lowHeadTime: data.lowHeadTime || 0,
          lowHeadCount: data.lowHeadCount || 0,
          phoneUseTime: data.phoneUseTime || 0,
          score: data.score || 100,
          totalConnectionTime: data.totalConnectionTime || 0,
          lastTimestamp: data.timestamp
        });
      }
    }  catch (error) {
      wx.showToast({
        title: error.message || '请求失败',
        icon: 'none',
        duration: 2000
      });
    } finally {
      this.setData({ isRefreshing: false });
    }
  },
  
  async requestBackend(endpoint, method, data = null) {
    if (app.globalData.tokenExpire < Date.now() / 1000) {
      try {
        await this.refreshToken(); 
      } catch (error) {
        this.stopMonitoring();
        throw new Error('登录已过期');
      }
    }
  
    return new Promise((resolve, reject) => {
      wx.request({
        url: `${config.apiBaseUrl}${endpoint}`,
        method,
        data,
        timeout: 3000,
        header: {
          'Authorization': `Bearer ${app.globalData.token}`
        },
        success: (res) => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(res.data);
          } else {
            reject(res.data?.message || '请求失败');
          }
        },
        fail: () => reject('网络异常，请检查连接')
      });
    });
  },

  //更新 token
  async refreshToken() {
    const { refreshToken } = app.globalData;
    try {
      const res = await wx.request({
        url: `${config.apiBaseUrl}/refresh`,
        method: 'POST',
        data: { refresh_token: refreshToken }
      });
      app.globalData.token = res.data.token;
      app.globalData.tokenExpire = Math.floor(Date.now()/1000) + res.data.expires_in;
      return true;
    } catch (e) {
      this.stopMonitoring();
      this.setData({ showLoginPopup: true });
      throw new Error('登录已过期');
    }
  },

  onUnload() {
    this.stopMonitoring();
  }
});
