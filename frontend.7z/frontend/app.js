// app.js（登录封装）
App({
  globalData: {
    userInfo: null,  //  用户
    token: null,  //  token
    tokenExpire: 0,  //  时间戳
    refreshToken: null,  // 刷新token
    loginStatusChangeCallbacks: []  //回调
  },

  // 登录方法封装
  login(callback) {
    wx.login({ 
      success: (res) => {
        const code = res.code; // 临时凭证
        wx.getUserProfile({
          desc: '身份验证',
          success: (userRes) => {
            // code + userInfo 发送
            wx.request({
              url: `${config.apiBaseUrl}/auth`,
              method: 'POST',
              data: { code, userInfo: userRes.userInfo },
              success: (apiRes) => {
                this.globalData.token = apiRes.data.token; 
                callback(userRes.userInfo);
              }
            });
          }
        });
        if (this.globalData.loginStatusChangeCallbacks) {
          this.globalData.loginStatusChangeCallbacks.forEach(cb => cb(true));
        }
      }
    });
  },
  
  onLoginStatusChange(callback) {
    this.globalData.loginStatusChangeCallbacks.push(callback);
  },

  // 检查登录
  checkLogin() {
    return !!this.globalData.userInfo
  }
})